const getBtn = document.getElementById("getToken")

const ext = typeof browser !== "undefined" ? browser : chrome

getBtn.addEventListener("click", async () => {
	const [tab] = await ext.tabs.query({
		active: true,
		currentWindow: true,
	})

	ext.scripting.executeScript(
		{
			target: { tabId: tab.id },
			func: () => {
				return (
					localStorage.getItem("token") ||
					localStorage.getItem("access_token") ||
					localStorage.getItem("jwt") ||
					localStorage.getItem("auth_token")
				)
			},
		},
		async (results) => {
			if (!results || !results[0] || !results[0].result) {
				alert("Token não encontrado")
				return
			}

			const token = results[0].result

			await fetch("https://oddscanner.onrender.com/save-token", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ token }),
			})

			alert("Token sincronizado com o Scanner!")
			window.close()
		},
	)
})